#!/bin/sh
./scan 00-div-mod.imp 00-div-mod.mr
./scan 0-div-mod.imp 0-div-mod.mr              
./scan 1-numbers.imp 1-numbers.mr
./scan 2-fib.imp 2-fib.mr
./scan 3-fib-factorial.imp 3-fib-factorial.mr
./scan 4-factorial.imp 4-factorial.mr
./scan 5-tab.imp 5-tab.mr
./scan 6-mod-mult.imp 6-mod-mult.mr
./scan 7-loopiii.imp 7-loopiii.mr
./scan 8-for.imp 8-for.mr
./scan 9-sort.imp 9-sort.mr
./scan program0.imp program0.mr
./scan program1.imp program1.mr
./scan program2.imp program2.mr
./scan error0.imp error0.mr
./scan error1.imp error1.mr
./scan error2.imp error2.mr
./scan error3.imp error3.mr
./scan error4.imp error4.mr
./scan error5.imp error5.mr
./scan error6.imp error6.mr
./scan error7.imp error7.mr
./scan error8.imp error8.mr
./scan test0.imp test0.mr
./scan test1a.imp test1a.mr
./scan test1b.imp test1b.mr
./scan test1c.imp test1c.mr
./scan test1d.imp test1d.mr
./scan test2.imp test2.mr
#scan


